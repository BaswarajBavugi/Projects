import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = "http://localhost:8080"

  private httpHeaders?: HttpHeaders;

  private currentUser:any;

  constructor(private http:HttpClient) { 
    this.updateCommonHeader()
  }

  getCurrentUser(){
    return this.currentUser
  }

  updateCurrentUser(user:any){
    this.currentUser = user
  }

  updateCommonHeader(){
    this.httpHeaders = new HttpHeaders({
      'Content-Type' : 'application/json',
       'Authorization' : 'Bearer ' + sessionStorage.getItem("access_token")
    });
  }

  private getHttpOptions():any{
    return{
      headers:this.httpHeaders,
    };
  }

  loginUser(credentials:{email:string, password: string}):Observable<any>{
    return this.http.post(`${this.baseUrl}/loginAccount`,credentials);
  }

  registerUser(userData:any) : Observable<any>{
    console.log(userData)
    return this.http.post<any>(`${this.baseUrl}/register`,userData)
  }

  getAllPackages(){
    return this.http.get(`${this.baseUrl}/getAllPackage`,this.getHttpOptions())
  }

  addPackage(packageData:any){
    console.log(packageData)
    return this.http.post<any>(`${this.baseUrl}/addPackage`,packageData,this.getHttpOptions())
  }

  updatePackage(packageData:any, packageId:any){
    let option ={ 
      headers:this.httpHeaders,
      params: new HttpParams().set('id', packageId) 
    }
    return this.http.put<any>(`${this.baseUrl}/updatePackage`,packageData,option)
  }

  getPackage(packageId:any){
    let option ={ 
      headers:this.httpHeaders,
      params: new HttpParams().set('id', packageId) 
    }
    return this.http.get(`${this.baseUrl}/getPackage`, option)
  }

  deletePackage(packageId:any){
    let option ={ 
      headers:this.httpHeaders,
      params: new HttpParams().set('id', packageId) 
    }
    return this.http.delete<any>(`${this.baseUrl}/deletePackage`,option)
  }

  getAllUser(){
    let option ={ 
      headers:this.httpHeaders,
    }
    return this.http.get(`${this.baseUrl}/getAllUser`, option)
  }

  booking(bookingData:any) : Observable<any>{
    console.log(bookingData)
    return this.http.post<any>(`${this.baseUrl}/addBooking`,bookingData,this.getHttpOptions())
  }


  getAllBooking(){
    let option ={ 
      headers:this.httpHeaders,
    }
    return this.http.get(`${this.baseUrl}/getAllBooking`, option)
  }

  getUserId(){
    return sessionStorage.getItem("uId");
  }

  getUserBooking(username:any){
    const data ={...{
      params:new HttpParams().set('username',username),    
    }, ...this.getHttpOptions()}
    console.log(data)
    return this.http.get(`${this.baseUrl}/userBooking`, data)
  }

  getPackageById(id: any): Observable < any > {
    const data ={...{
      params:new HttpParams().set('id',id),    
    }, ...this.getHttpOptions()}
    console.log(data)
    return this.http.get<any>(`${this.baseUrl}/getPackage`, data);
  }

}
