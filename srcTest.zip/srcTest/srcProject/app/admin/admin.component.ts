import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  addPackageClicked:boolean = true;
    usersClicked:boolean =false;
    bookingsClicked : boolean = false;
     

  clickAddPackage(){
    this.addPackageClicked=true;
    this.usersClicked=false;
    this.bookingsClicked=false;
}
clickUsers(){
  this.addPackageClicked=false;
  this.usersClicked=true;
  this.bookingsClicked=false;
}
clickBookings(){
  this.addPackageClicked=false;
    this.usersClicked=false;
    this.bookingsClicked=true;
}
}
