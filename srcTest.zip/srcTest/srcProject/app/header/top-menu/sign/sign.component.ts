import { HttpClient } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign',
  templateUrl: './sign.component.html',
  styleUrls: ['./sign.component.css']
})
export class LoginComponent{
  signInClicked:boolean=true;
  signUpClicked:boolean=false;
  //  loginForm!:FormGroup; 
  // constructor(private router: Router) {}
  // ngOnInit(): void {
  //    this.loginForm=new FormGroup(
  //     {
  //       userName:new FormControl(''),
  //       password:new FormControl('')
  //     }
  //    )
  // }
  
 
  // login() {
      
  //     alert('Login successful. Now you can book a tour !!!')
  //     this.router.navigateByUrl('/booking');
  //   }
  onSignIn(){
    this.signInClicked=true;
    this.signUpClicked=false;

  }
  onSignUp(){
    this.signInClicked=false;
    this.signUpClicked=true;
  }
}
