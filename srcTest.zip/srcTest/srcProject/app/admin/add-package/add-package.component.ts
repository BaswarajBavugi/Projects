import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-package',
  templateUrl: './add-package.component.html',
  styleUrls: ['./add-package.component.css']
})
export class AddPackageComponent {
    
  adminForm!:FormGroup; 
  constructor(private router: Router) {}
  ngOnInit(): void {
     this.adminForm=new FormGroup(
      {
        packageName:new FormControl(''),
        image:new FormControl(''),
        price:new FormControl(''),
        numOfDays:new FormControl(''),
        description:new FormControl('')

      }
     )

  }
  

}
