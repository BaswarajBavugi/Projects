import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css']
})
export class TopMenuComponent implements OnInit {
isLoggedIn= false;

constructor(){
  
}
  ngOnInit(): void {
    this.isLoggedIn = !!(sessionStorage.getItem("access_token"))
  }

onClickLogOut(){
  sessionStorage.removeItem("access_token")
  this.isLoggedIn = false;
}

}
