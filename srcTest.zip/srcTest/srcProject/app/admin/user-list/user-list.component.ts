import { Component } from '@angular/core';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent {
  userList = [{
    name:'Baswaraj',
    phNum : 9391057359,
    email:'baswa@sol.com',
    gender:'Male',
    Address:'Hyderabad',
    Age:22
  }];
}
