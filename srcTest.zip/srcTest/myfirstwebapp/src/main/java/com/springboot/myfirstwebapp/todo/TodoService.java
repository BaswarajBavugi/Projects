package com.springboot.myfirstwebapp.todo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class TodoService {
	
	private static List<Todo> todos=new ArrayList<>();
	private static int todoCount=0;
	static {
		todos.add(new Todo(++todoCount,"baswaraj","Learn Linux",LocalDate.now().plusYears(1),false));
		todos.add(new Todo(++todoCount,"baswaraj","Learn AWS",LocalDate.now().plusYears(2),false));
		todos.add(new Todo(++todoCount,"baswaraj","Learn Git",LocalDate.now().plusYears(1),false));
	}
	
	public List<Todo> findByUserName(String userName){
		return todos;
	}
	
	public void addTodo(String userName,String Description, LocalDate targetDate, boolean done) {
		Todo todo = new Todo(++todoCount,userName,Description,targetDate,done);
		todos.add(todo);
	}
}
