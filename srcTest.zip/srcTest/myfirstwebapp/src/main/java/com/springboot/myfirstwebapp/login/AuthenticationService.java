package com.springboot.myfirstwebapp.login;

import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {
	
	public boolean authenticate(String name,String password) {
		boolean isValidUser= name.equals("Baswaraj");
		boolean isValidPassword=password.equals("Bavugi");
		return isValidUser && isValidPassword;
	}
}
