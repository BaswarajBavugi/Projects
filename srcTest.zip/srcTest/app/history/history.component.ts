import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit{
  userBooking:any;
  bookingPackage:any;

  constructor(private apiService:ApiService,private route:ActivatedRoute)
  {


  }
  ngOnInit(): void {
    this.getHistory();
  }

  getPackageById(){
    this.apiService.getPackageById(this.userBooking.packageId).subscribe(data=>{
      this.bookingPackage =data;
    })

  }

  getHistory(){
    this.apiService.getUserBooking(this.apiService.getCurrentUser().username).subscribe(data=>{
      this.userBooking =data;

    })
  }

}
