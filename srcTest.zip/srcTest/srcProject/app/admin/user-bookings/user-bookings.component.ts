import { Component } from '@angular/core';

@Component({
  selector: 'app-user-bookings',
  templateUrl: './user-bookings.component.html',
  styleUrls: ['./user-bookings.component.css']
})
export class UserBookingsComponent {
  userBookings = [{
    name:'Baswaraj',
    package : 'Hyderabad',
    num_of_members : 10,
    date : new Date(),
    phNum : 9391057359,
    email:'baswa@sol.com'
  }];

}
