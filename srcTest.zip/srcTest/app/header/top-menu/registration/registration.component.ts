import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  registration:any = FormGroup;
  

  constructor(private router: Router,private http: HttpClient, private apiService: ApiService, private fb:FormBuilder ){

  }
  ngOnInit(){
    this.registration =this.fb.group({
      name: [''],
      email: [''],
      password: [''],
      mobile: [''],
      gender: [''],
      address: [''],
      role:[false]
    })
  }

  save(){
  
    let bodyData = {
      "name" : this.registration.value.name,
      "gender":this.registration.value.gender,
      "email" : this.registration.value.email,
      "mobile" : this.registration.value.mobile,
      "password" : this.registration.value.password,
      "address":this.registration.value.address,
      "role": this.registration.value.role ? "ADMIN": "USER"
    };
    this.apiService.registerUser(bodyData).subscribe((resultData: any)=>
    {
        console.log(resultData);
        if(resultData){
          alert("Employee Registered Successfully");
          this.router.navigateByUrl('/login');

        }else{
          alert('Registered successfully. Now you can login !!!')
        }
    });
    // console.log(bodyData);
    
    
     
  }
}
