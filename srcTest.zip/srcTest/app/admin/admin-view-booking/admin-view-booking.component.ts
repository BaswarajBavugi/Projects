import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-admin-view-booking',
  templateUrl: './admin-view-booking.component.html',
  styleUrls: ['./admin-view-booking.component.css']
})
export class AdminViewBookingComponent implements OnInit{
  bookingall:any;
  constructor( private http: HttpClient, private apiService: ApiService, private fb: FormBuilder) {
    
 }
  ngOnInit(): void {
    this.apiService.getAllBooking().subscribe(data=>{
      this.bookingall=data;
    })
  }


}
