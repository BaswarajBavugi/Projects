import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/service/api.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  packages: any = [];
  isAdmin = false;
  // packages:any = []
  constructor(private readonly apiService: ApiService){}

  ngOnInit(){
    this.isAdmin = this.apiService.getCurrentUser()?.role === "ADMIN" || false;
    this.getAllPackages()
  }
  getAllPackages(){
    this.apiService.getAllPackages().subscribe(res =>{
      if(res)
      this.packages = res
    })      
  }

  updateListOnDeletePackage(packageId:any){
    console.log("event return")
    this.getAllPackages()
  }
  
totalPackages=this.packages.length;
// heighestRated=this.packages.filter(p=>p.Avg_rating>4.5).length
// mostBooked=this.packages.filter(p=>p.Num_bookings>8).length
}
