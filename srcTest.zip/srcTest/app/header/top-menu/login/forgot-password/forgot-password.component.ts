import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {
  forgotPasswardForm!: FormGroup;
  constructor(private router: Router){
    
  }

  ngOnInit(): void {
    this.forgotPasswardForm=new FormGroup(
     {
       email:new FormControl(''),
       newPassword:new FormControl(''),
       confirmPassword:new FormControl('')
     }
    )
 }

save(){
  this.router.navigateByUrl('/login');
  alert('Your password has set. Now you can login !!!')
}
}
