import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class SignComponent  implements OnInit{
  loginForm!:FormGroup; 
  constructor(private router: Router) {}
  ngOnInit(): void {
     this.loginForm=new FormGroup(
      {
        userName:new FormControl(''),
        password:new FormControl('')
      }
     )
  }
  
 
  login() {
      
      alert('Login successful. Now you can book a tour !!!')
      this.router.navigateByUrl('/booking');
    }
}
