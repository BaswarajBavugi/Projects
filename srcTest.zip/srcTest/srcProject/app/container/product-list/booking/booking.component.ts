import { Component, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent {
  BookingForm!:FormGroup; 
  constructor(private router: Router) {}
  ngOnInit(): void {
     this.BookingForm=new FormGroup(
      {
        userName:new FormControl(''),
        phNum:new FormControl(''),
        package:new FormControl(''),
        ticketNum:new FormControl('')
      }
     )
  }
  
  book(){
    this.router.navigateByUrl('')
  }
}
